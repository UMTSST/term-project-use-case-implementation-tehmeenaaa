#include <iostream>
#include <fstream>
#include <cstdlib>
using namespace std;

int main()
{
    ifstream inFile;
    string word;
    inFile.open("Twitter.txt");
    if (!inFile) {
    cerr << "Unable to open file Twitter.txt";
    exit(1);   // call system to stop
}


    while (inFile >> word) {
        cout<<word<<endl;
    }

    inFile.close();

    return 0;
}
